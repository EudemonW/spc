import os

from django.http import HttpResponse

from spcapi.model.dbcommon import dbcommon
from spcapi.model.spc import create
from spcapi.model.spcSource import spcSource
import json

class api():
    def __init__(self):
        self.mdb = dbcommon()
        pass

    def hello(request):


        return HttpResponse("hello")

    def saveDevice(request):
        spcSource().save(request.GET)
        req = {}
        req["code"]=0
        req["msg"]="save ok"
        return HttpResponse(json.dumps(req))

    def getDevice(request):
        no = request.GET["no"]
        df = spcSource().getList(no)
        create(df,no)
        HTML = "<H1 style='text-align: center;'> 设备编号 「{no}」</H1>".format(no=no)
        HTML += "<hr width='100%'/>"
        HTML += "<H3 style='text-align: center;'> 设备尺寸类别 「A」</H3>".format(no=no)
        HTML += "<img width='100%' src='/api/getImg?no={no}_A'>".format(no=no)
        HTML += "<hr width='100%'/>"
        HTML += "<H3 style='text-align: center;'> 设备尺寸类别 「B」</H3>".format(no=no)
        HTML += "<img width='100%' src='/api/getImg?no={no}_B'>".format(no=no)
        HTML += "<hr width='100%'/>"
        HTML += "<H3 style='text-align: center;'> 设备尺寸类别 「C」</H3>".format(no=no)
        HTML += "<img width='100%' src='/api/getImg?no={no}_B'>".format(no=no)
        HTML += "<hr width='100%'/>"
        HTML += "<H3 style='text-align: center;'> 设备尺寸类别 「D」</H3>".format(no=no)
        HTML += "<img width='100%' src='/api/getImg?no={no}_C'>".format(no=no)
        return HttpResponse(HTML)

    def createImage(self,no):
        pass

    def img(request):
        no = request.GET["no"]
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = base_dir+"/static/{no}.png".format(no=no)
        if os.path.exists(path):
            image_data = open(base_dir+"/static/{no}.png".format(no=no), "rb").read()
            return HttpResponse(image_data, content_type="image/png")
        return HttpResponse("can not find device")
