from time import time

from spcapi.model.dbcommon import dbcommon


class spcSource(dbcommon):
    def __init__(self):
        self.mdb = dbcommon()


        pass

    def save(self,data):
        SQL="INSERT INTO `spc_source` (`id`, `device_no`, `size_type`, `change_val`, `control_up`, `control_center`, `control_down`, `timestamp`)" \
            " VALUES (NULL, '{device_no}', '{size_type}', '{change_val}', '{control_up}', '{control_center}', '{control_down}', '{timestamp}');"\
            .format(device_no=data["device_no"],size_type=data["size_type"],change_val=data["change_val"],control_center=data["control_center"],control_up=data["control_up"],control_down=data["control_down"],timestamp=data["timestamp"])
        self.mdb.execute(SQL)


    def getList(self,no):
        SQL = "SELECT * FROM spc_source where device_no = {no}".format(no=no)
        return self.mdb.readQuery(SQL)